import time
from agents.perception_agent import PerceptionAgent
from agents.reasoning_agent import ReasoningAgent
from agents.planning_agent import PlanningAgent

def run_inspection_loop():
    print("[System] Initializing GridSense-Agent...")
    perception = PerceptionAgent()
    reasoning = ReasoningAgent()
    planner = PlanningAgent()

    while True:
        # 1. Perception Step
        depth_map, anomalies = perception.get_scene_analysis()
        print(f"[Perception] Detected {len(anomalies)} potential targets.")

        # 2. Reasoning Step
        if anomalies:
            decision = reasoning.analyze_fault_risk(anomalies, depth_map)
            print(f"[Reasoning] Analysis Result: {decision['logic']}")

            # 3. Planning Step
            if decision['action_required']:
                planner.execute_task(decision['task'])
        
        time.sleep(5)

if __name__ == "__main__":
    run_inspection_loop()
