# GridSense-Agent: Multi-modal Perception & Reasoning for Smart Grid Inspection

## 🚀 Project Overview
GridSense-Agent is an AI-driven autonomous system designed for power grid infrastructure inspection. It integrates high-precision computer vision (Stereo Matching) with Large Language Model (LLM) reasoning capabilities to solve complex perception and decision-making tasks in unstructured environments.

## 🧠 Core Architecture
The system employs a **Multi-Agent Collaboration** framework:
- **Perception Agent**: Utilizes **MMGA-KAN Net** (Multimodal Graph Attention Kolmogorov-Arnold Network) for high-accuracy binocular depth estimation.
- **Reasoning Agent**: Implements **Chain-of-Thought (CoT)** reasoning to analyze equipment health based on multimodal sensor fusion.
- **Planning Agent**: Coordinates task execution and dynamic trajectory optimization.

## 📂 Repository Structure
- `agents/`: Core logic for perception, reasoning, and planning.
- `models/`: Neural network architecture definitions.
- `main.py`: Entry point for the simulation loop.
