class PlanningAgent:
    def execute_task(self, task):
        print(f'| Planning | Executing: {task}')
