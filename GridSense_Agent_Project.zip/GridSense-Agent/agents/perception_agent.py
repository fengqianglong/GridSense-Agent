class PerceptionAgent:
    def __init__(self):
        self.model_name = "MMGA-KAN-Net"
        print(f"| Perception | Loaded model: {self.model_name}")

    def get_scene_analysis(self):
        return "depth_tensor_3d", [{"type": "insulator", "coord": [120, 450], "status": "suspect"}]
